#include "window.h"
#include "ui_window.h"

Window::Window(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Window)
{
    ui->setupUi(this);
    //sock.connectToHost("127.0.0.1",4321);
    aa = false;
    vert = 0;
    horiz = 0;
    scalar = 1.0;

    connect(&sock, SIGNAL(readyRead()), this, SLOT(receiveData()));
    connect(&sock, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(disconnect()));
    //connect(&sock, SIGNAL(disconnected()), this, SLOT(reconnect()));
}

Window::~Window()
{
    delete ui;
}

void Window::paint(QPainter& painter)
{
    QTransform transform;
    //reflect due to different coordinate system of QPainter
    transform.scale(scalar,-scalar);
    painter.setWorldTransform(transform);
    if(aa)
        painter.setRenderHint(QPainter::Antialiasing, true);

    painter.setViewport(this->width()/2 +horiz,this->height()/2 +vert,this->width(),this->height());
    foreach(QPointF point, map_points) {
        painter.drawPoint(point);
    }
}

void Window::paintEvent(QPaintEvent * event)
{
    QPainter p(this);
    paint(p);
}

void Window::wheelEvent(QWheelEvent * event)
{
    int numDegrees = event->delta() / 8;
    int numSteps = numDegrees / 15;
    scalar += 0.1 * numSteps;
    event->accept();
    update(); //schedule a repaint
}

void Window::keyPressEvent(QKeyEvent * event)
{
    if(event->key() == Qt::Key_C) {
        reconnect();
    }
    else if(event->key() == Qt::Key_D) {
        disconnect();
    }
    else if(event->key() == Qt::Key_A) {
        toggleAA();
    }
    else if(event->key() == Qt::Key_S) {
        saveMap();
    }
    else if(event->key() == Qt::Key_Right) {
        ++horiz;
    }
    else if(event->key() == Qt::Key_Left) {
        --horiz;
    }
    else if(event->key() == Qt::Key_Up) {
        --vert;
    }
    else if(event->key() == Qt::Key_Down) {
        ++vert;
    }
    update();
}

void Window::toggleAA()
{
    aa = aa ? false : true;
    update();
}

void Window::saveMap()
{
    QImage tmp(this->width(),this->height(),QImage::Format_ARGB32_Premultiplied);

    QPainter p(&tmp);
    paint(p);
    tmp.save(QString("map.png"));
}

void Window::disconnect()
{
    sock.disconnectFromHost();
}

void Window::reconnect()
{
    if(!sock.isValid())
        sock.connectToHost("127.0.0.1",4321);
}

void Window::receiveData()
{
    std::size_t size = 10*sizeof(double);
    char tmp[size];
    std::size_t bytes = sock.read(tmp, size);
    double * test = (double*) tmp;
    if(bytes == size) {
        QString str("Received 5 points: ");

        //pretty printing
        for(int i=0; i<10; i+=2) {
            str += QString("(")
                +  QString::number(test[i]) + QString(",") + QString::number(test[i+1]);
            if(i<8)
                str += QString("), ");
            else
                str += QString(")");
            //scale to 1/20 to be closer to QPainter's coordinates
            addPoint(QPointF(test[i], test[i+1])/20);
        }

        qDebug() << str;
    }
}

void Window::addPoint(QPointF point)
{
    map_points << point;
    update();
}

void Window::ransac()
{

}
