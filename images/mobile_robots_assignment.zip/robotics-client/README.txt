Requirements:
Qt 4.7+

To Compile:
run "qmake robotics-client.pro" to generate Makefile for your platform
then just run "make"