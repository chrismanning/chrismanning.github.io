#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>
#include <QPainter>
#include <QList>
#include <QPointF>
#include <QLineF>
#include <QTcpSocket>
#include <QKeyEvent>
#ifndef QT_NO_OPENGL
#include <QtOpenGL>
#endif
#include <math.h>

namespace Ui {
class Window;
}

class Window : public QWidget
{
    Q_OBJECT
    
public:
    explicit Window(QWidget *parent = 0);
    ~Window();

public slots:
    void receiveData();
    void disconnect();

protected:
    void paintEvent(QPaintEvent * event);
    void keyPressEvent(QKeyEvent * event);
    void wheelEvent(QWheelEvent * event);
    void addPoint(QPointF point);
    void reconnect();
    void toggleOpenGL();
    void toggleAA();
    void saveMap();

private:
    bool aa;
    Ui::Window *ui;
    QList<QPointF> map_points;
    QList<QLineF> edges;
    void ransac();
    QTcpSocket sock;
    void paint(QPainter& painter);
    int vert;
    int horiz;
    qreal scalar;
};

#endif // WINDOW_H
