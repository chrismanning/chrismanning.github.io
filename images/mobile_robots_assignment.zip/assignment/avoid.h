#ifndef AVOID_H
#define AVOID_H

#include "Aria.h"

class Avoid : public ArAction
{
public:
    Avoid();
    virtual ~Avoid() {};
    virtual ArActionDesired * fire(ArActionDesired d);
    ArActionDesired desiredState;
protected:
    enum STATE {
        IDLE,
        TURN_LEFT,
        TURN_RIGHT
    };
    int speed;
    double proximity;
    double limit;
    int state;
    double angle;
    double heading;
};

#endif
