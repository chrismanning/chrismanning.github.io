#include "map.h"

Map::Map() : ArAction("Make a map")
{
    if(listener.open(4321,ArSocket::TCP)) {
        ArLog::log(ArLog::Normal, "MAP: opened the port 4321.");
    }
    counter = 0;
    angles.push_back(30); angles.push_back(-30);
    angles.push_back(90); angles.push_back(30);
    angles.push_back(150); angles.push_back(90);
    angles.push_back(-30); angles.push_back(-90);
    angles.push_back(-90); angles.push_back(-150);
    //ArSocket::accept blocks so use ArThread with it
    functor = new ArFunctorC<Map>(this,&Map::accept);
    listen_thread.create(functor);
}

ArActionDesired * Map::fire(ArActionDesired d)
{
    desiredState.reset();

    //if(listener.accept(&sock)) {
    //    ArLog::log(ArLog::Normal, "MAP: client connected.");
    //}
    if(counter > 16) {
        counter = 0;
    }
    if(!(counter % 2)) {
        r = myRobot->checkRangeDevicesCurrentPolar(angles[counter/2],angles[(counter/2)+1],&ths); //includes radius
        ArLog::log(ArLog::Verbose,"MAP: reading distance: %.2f",r);
        if(r < 3500 && sock.getFD()) {
            xr  = myRobot->getX();
            yr  = myRobot->getY();
            thr = -myRobot->getTh();

            //ArMath works in degrees
            x = ArMath::cos(ths) * r;
            y = ArMath::sin(ths) * r;

            ArMath::pointRotate(&x, &y, thr);
            //xs = (x * ArMath::cos(thr)) - (y * ArMath::sin(thr));
            //ys = (x * ArMath::sin(thr)) + (y * ArMath::cos(thr));
            //xs += xr;
            //ys += yr;
            xs = xr + x;
            ys = yr + y;

            points.push_back(xs);
            points.push_back(ys);
            if(points.size() == 10) { //try to send 5 points at a time
                std::size_t size = points.size() * sizeof(double);
                if(sock.write(&points[0], size) == size) {
                    ArLog::log(ArLog::Normal, "sent 5 map points");
                }
                else { //fail to write may mean the client isn't there
                    sock.close();
                    if(listen_thread.isThreadFinished()) {
                        listen_thread.cancelAll();
                        listen_thread.create(functor);
                    }
                }
                counter = 0;
                points.clear();
            }
        }
    }
    counter++;

    return &desiredState;
}

void Map::accept()
{
    while(true) {//allows client to reconnect to same session
        if(listener.accept(&sock)) {
            ArLog::log(ArLog::Normal,"MAP: client connected");
        }
    }
}
