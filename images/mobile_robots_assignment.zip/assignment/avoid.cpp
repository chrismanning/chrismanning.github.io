#include "avoid.h"


Avoid::Avoid() : ArAction("Avoid obstacles")
{
    speed = 50;
    limit = 150;
    state = IDLE;
    proximity = 250;
    //nice and high so that it turns sharper when needed
    heading = 135;
}

ArActionDesired * Avoid::fire(ArActionDesired d)
{
    desiredState.reset();
    double dist;

    switch(state) {
    case IDLE:
        dist = myRobot->checkRangeDevicesCurrentPolar(-60,60, &angle) - myRobot->getRobotRadius();
        if(dist <= proximity) {
            speed = 25;
            if(angle > 0) {
                state = TURN_RIGHT;
            }
            else {
                state = TURN_LEFT;
            }
        }
        else {
            speed = 50;
        }
        break;
    case TURN_LEFT:
        ArLog::log(ArLog::Normal,"AVOID: turning %.2f degrees", heading);
        desiredState.setDeltaHeading(heading);
        desiredState.setVel(speed);
        state = IDLE;
        break;
    case TURN_RIGHT:
        ArLog::log(ArLog::Normal,"AVOID: turning %.2f degrees", -heading);
        desiredState.setDeltaHeading(-heading);
        desiredState.setVel(speed);
        state = IDLE;
        break;
    default:
        break;
    }

    return &desiredState;
}
