#ifndef MAP_H
#define MAP_H

#include <math.h>
#include <Aria.h>
#include <vector>

class Map : public ArAction
{
public:
    Map();
    virtual ~Map() {
        delete functor;
        listener.close();
        sock.close();
    }
    virtual ArActionDesired * fire(ArActionDesired d);
    ArActionDesired desiredState;
protected:
    double x,xr,xs,y,yr,ys,thr,ths,r;
    ArSocket sock, listener;
private:
    void accept();
    ArThread listen_thread;
    ArFunctor * functor;
    int counter;
    std::vector<double> angles;
    std::vector<double> points;
};

#endif
