#ifndef WANDER_H
#define WANDER_H

#include <iostream>
#include <stdlib.h>
#include <Aria.h>

class Wander :
    public ArAction
{
public:
    Wander();
    virtual ~Wander() {}
    virtual ArActionDesired * fire(ArActionDesired d);
    ArActionDesired desiredState;
private:
    enum STATE {
        FORWARD,
        TURN
    };
    int state;
    double heading;
    double distance;
    double travelled;
    double old_x;
    double old_y;
    double angle;
    double old_theta;
    int speed;
    bool turnComplete();
};
#endif
