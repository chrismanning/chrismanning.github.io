#ifndef RINGBUFFER_H
#define RINGBUFFER_H

#include <iostream>
#include <numeric>

/*
    Simple ring buffer implementation.
    Made it a template so that I could use buffer[elements]
    which simplifies things a whole lot + eliminates lots
    of memory allocations
*/
template <unsigned int elements>
class RingBuffer
{
public:
    RingBuffer() {
        in = 0;
        //initialise all elements
        for(int i=0; i<elements;++i)
            buffer[i] = 0.0;
    };
    virtual ~RingBuffer() {};
    void add(double element) {
        buffer[in] = element;
        ++in;
        if(in == (elements-1)) {
            in = 0;
        }
    }
    double sum() {
        return std::accumulate(buffer, buffer+elements,0.0);
    }
    void printBuffer() {
        std::cout << "[";
        for(int i=0; i<elements; ++i)
            std::cout << buffer[i] << ", ";
        std::cout << "]" << std::endl;
    }
    double last() {
        if(in > 0)
            return buffer[in-1];
        else
            return buffer[elements-1];
    }
    double nextToLast() {
        if(in > 1)
            return buffer[in-2];
        else
            return buffer[elements-1];
    }
private:
    double buffer[elements];
    int in;
};

#endif
