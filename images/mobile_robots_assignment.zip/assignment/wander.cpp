#include "wander.h"

Wander::Wander() : ArAction("Wander around") {
    speed = 50;
    heading = 8;
    state = FORWARD;
    old_theta =
    old_x =
    old_y =
    angle =
    distance =
    travelled = 0;
}

ArActionDesired * Wander::fire(ArActionDesired d) {
    desiredState.reset();

    //std::cout << "distance: " << distance << ", travelled: " << travelled;
    //std::cout << ", th: " << myRobot->getTh() << ", angle: " << angle << std::endl;

    travelled = sqrt(pow(myRobot->getX() - old_x,2) + pow(myRobot->getY() - old_y,2));

    switch(state) {
    case FORWARD:
        if(travelled >= distance) {
            state = TURN;
        }
        break;
    case TURN:
        if(!turnComplete()) {
            desiredState.setDeltaHeading(heading);
        }
        else {
            //std::cout << "turned: " << angle << " degrees" << std::endl;
            old_x = myRobot->getX();
            old_y = myRobot->getY();
            old_theta = myRobot->getTh();
            state = FORWARD;
            distance = (rand() % 1000) + 500; //get pseudo-random num between 500 & 1500
            angle = (rand() % 140) + 20; //get pseudo-random num between 20 & 160

            if((bool)((int)angle % 2)) { //if angle is odd turn right
                angle = -angle;
                heading = -fabs(heading);
            }
            else {
                heading = fabs(heading);
            }
            travelled = 0;
            ArLog::log(ArLog::Normal,"WANDER: turning %.2f degrees after %.2f mm", angle, distance);
        }
        break;
    default:
        break;
    }
    desiredState.setVel(speed);

    return &desiredState;
}

bool Wander::turnComplete() {
    double current_theta = myRobot->getTh();
    double aim = ArMath::addAngle(old_theta,angle);

    return current_theta >= aim - 5 && current_theta <= aim + 5;
}
