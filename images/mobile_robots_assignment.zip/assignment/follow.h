#ifndef FOLLOW_H
#define FOLLOW_H

#include <iostream>
#include <stdlib.h>
#include <Aria.h>

#include "ringbuffer.h"

class Follow : public ArAction // Class action inherits from ArAction
{
public:
    Follow(); // Constructor
    virtual ~Follow() {}  // Destructor
    virtual ArActionDesired * fire(ArActionDesired d);
    ArActionDesired desiredState;
protected:
    int speed; // Speed of the robot in mm/s
    double deltaHeading; // Change in heading
    enum STATE {
        IDLE,
        FOLLOW
    };
    int state;
    // Control variables
    double setPoint; // Set point of the controller
    double error; // Current error
    double output; // Final output signal
    double pGain; // Gain
    double proportional;
    double iGain;
    double integral;
    double dGain;
    double derivative;
    double radius;
    double last_angle;
    double last_out;
    RingBuffer<50u> buf;
    bool first;
};
#endif
